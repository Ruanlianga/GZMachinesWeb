create definer = ruanliang@localhost view car_ma_type_info as
select `cmt`.`id`          AS `id`,
       `cmt`.`name`        AS `model`,
       `cmt1`.`name`       AS `name`,
       `cmt2`.`name`       AS `type`,
       `cmt`.`unit_name`   AS `unit`,
       `cmt`.`level`       AS `level`,
       `cmt`.`storage_num` AS `num`
from ((`gzimt250319`.`car_ma_type` `cmt` left join `gzimt250319`.`car_ma_type` `cmt1`
       on (((`cmt`.`parent_id` = `cmt1`.`id`) and (`cmt1`.`is_active` = 1)))) left join `gzimt250319`.`car_ma_type` `cmt2`
      on (((`cmt1`.`parent_id` = `cmt2`.`id`) and (`cmt2`.`is_active` = 1))))
where ((`cmt`.`is_active` = 1) and (`cmt`.`level` = 4));

-- comment on column car_ma_type_info.id not supported: 主键

-- comment on column car_ma_type_info.model not supported: 名称

-- comment on column car_ma_type_info.name not supported: 名称

-- comment on column car_ma_type_info.type not supported: 名称

-- comment on column car_ma_type_info.unit not supported: 计量单位

-- comment on column car_ma_type_info.level not supported: 层级

-- comment on column car_ma_type_info.num not supported: 库存

