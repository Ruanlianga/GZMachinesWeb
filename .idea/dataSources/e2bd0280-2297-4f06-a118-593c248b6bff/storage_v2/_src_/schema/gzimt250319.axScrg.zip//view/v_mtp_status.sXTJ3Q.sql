create definer = ruanliang@localhost view v_mtp_status as
select `mtp`.`machine` AS `maId`,
       `wla`.`CODE`    AS `agreementCode`,
       `bc`.`NAME`     AS `projectName`,
       `bp`.`NAME`     AS `companyName`
from ((((`gzimt250319`.`ma_type_project_storage` `mtp` left join `gzimt250319`.`mm_machines` `mm`
         on ((`mtp`.`machine` = `mm`.`ID`))) left join `gzimt250319`.`wf_lease_agreement` `wla`
        on ((`mtp`.`agreement_id` = `wla`.`ID`))) left join `gzimt250319`.`bm_project` `bp`
       on ((`wla`.`PROJECT` = `bp`.`ID`))) left join `gzimt250319`.`bm_company` `bc`
      on ((`bp`.`COMPANY_ID` = `bc`.`ID`)))
where ((`mm`.`BATCH_STATUS` = 6) and (`mtp`.`status` = 1));

