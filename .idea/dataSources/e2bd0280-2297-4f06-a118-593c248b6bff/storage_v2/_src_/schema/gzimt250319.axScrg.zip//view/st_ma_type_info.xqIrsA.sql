create definer = ruanliang@localhost view st_ma_type_info as
select `smt3`.`name`       AS `type`,
       `smt2`.`name`       AS `name`,
       `smt`.`name`        AS `model`,
       `smt`.`unit_name`   AS `unit`,
       `smt`.`id`          AS `model_id`,
       `smt`.`dbf_num`     AS `dbf_num`,
       `smt`.`storage_num` AS `num`,
       `smt`.`parent_id`   AS `parent_id`,
       `smt`.`check_cycle` AS `check_cycle`
from ((`gzimt250319`.`st_ma_type` `smt` left join `gzimt250319`.`st_ma_type` `smt2`
       on (((`smt`.`parent_id` = `smt2`.`id`) and (`smt2`.`level` = 2)))) left join `gzimt250319`.`st_ma_type` `smt3`
      on (((`smt2`.`parent_id` = `smt3`.`id`) and (`smt3`.`level` = 1))))
where ((`smt`.`level` = 3) and (`smt`.`is_active` = 0));

-- comment on column st_ma_type_info.type not supported: 名称

-- comment on column st_ma_type_info.name not supported: 名称

-- comment on column st_ma_type_info.model not supported: 名称

-- comment on column st_ma_type_info.unit not supported: 计量单位

-- comment on column st_ma_type_info.model_id not supported: 主键

-- comment on column st_ma_type_info.dbf_num not supported: 待报废数量

-- comment on column st_ma_type_info.num not supported: 库存

-- comment on column st_ma_type_info.parent_id not supported: 上一级

-- comment on column st_ma_type_info.check_cycle not supported: 周期

